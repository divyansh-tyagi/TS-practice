"use strict";
function show(a = 0, b = 0) {
    var c = a + b;
    console.log(c);
}
let t;
t = 100;
// let a:number=10;
// a=null;
console.log(show(10, 20));
