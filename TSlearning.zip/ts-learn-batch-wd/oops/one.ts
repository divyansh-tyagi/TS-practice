//class name must be a noun
//class <ClassName>


class Student{
    //data members / Instance variables
    rollno:number;
    name:string;
    marks:number[]
    //constructor-initialise the instance variables/data members
    constructor(rollno:number,name:string,marks:number[]){
        //this- keyword that  contains the current calling object reference address
        this.rollno=rollno;
        this.name=name;
        this.marks=marks;

    }
    show():void{
        console.log(`Rollno ${this.rollno} Name ${this.name} Marks ${this.marks}`);
    }

}
let ram:Student;
ram=new Student(1001,'Ram',[90,85,88]);
ram.show();
// ram.rollno=1001;
// ram.name="Ram Kumar";
// ram.marks=[90,88,85];
// //new keyword allocate dynamic memory
// console.log(ram.rollno);
// console.log(ram.name);
// console.log(ram.marks);