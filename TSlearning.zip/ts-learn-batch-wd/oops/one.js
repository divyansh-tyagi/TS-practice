//class name must be a noun
//class <ClassName>
var Student = /** @class */ (function () {
    //constructor-initialise the instance variables/data members
    function Student(rollno, name, marks) {
        //this- keyword that  contains the current calling object reference address
        this.rollno = rollno;
        this.name = name;
        this.marks = marks;
    }
    Student.prototype.show = function () {
        console.log("Rollno ".concat(this.rollno, " Name ").concat(this.name, " Marks ").concat(this.marks));
    };
    return Student;
}());
var ram;
ram = new Student(1001, 'Ram', [90, 85, 88]);
ram.show();
// ram.rollno=1001;
// ram.name="Ram Kumar";
// ram.marks=[90,88,85];
// //new keyword allocate dynamic memory
// console.log(ram.rollno);
// console.log(ram.name);
// console.log(ram.marks);
