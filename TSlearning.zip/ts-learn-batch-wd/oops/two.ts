//destructure

type Employee={
    id:number;
    name:string;
    salary:number;
}

// function show(obj:Employee){
//     console.log(obj.name, obj.salary);
// }

function show4(obj:{rollno:number, name:string}){
    console.log(obj.rollno, obj.name);
}
function show({name, salary}:Employee){
    console.log(name, salary);
}
function show2({id, salary}:{id:number, salary:number}){
    console.log(id, salary);
}

let e:Employee={id:1001, name:'Tim', salary:99999};
show(e);
show2({id:1000, salary:88888});