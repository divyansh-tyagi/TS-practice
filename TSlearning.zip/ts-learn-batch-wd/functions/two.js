//function parameter optional, default
//function n arguments
//fiunction overloading
//function object
function search(criteria) {
    if (typeof criteria === 'number') {
        console.log('Search By Price', criteria);
    }
    else {
        console.log('Search By Brand', criteria);
    }
}
search(10000);
search('Puma');
