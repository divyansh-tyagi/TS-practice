function add(x:number, y:number){
    return x+y;
}
let z=add(100,200);
console.log(z);
//implicit any
function adder(x,y):void{
    console.log(x+y);
}
//adder()

//Async
function doAsyncTask(num:number):Promise<number>{
    const promise:Promise<number> = new Promise<number>((resolve, reject)=>{
        setTimeout(()=>{
            resolve(num ** 3);
        },4000)
    },);
    return promise;
}
const promise:Promise<number>=doAsyncTask(3);
promise.then(data=>console.log('Cube', data)).catch(err=>console.log(err));

//Anonymous function or Arrow Function
let prices:number[]=[1000,2000,4000,50000]
prices.forEach((price:number)=>console.log('Price is',price));