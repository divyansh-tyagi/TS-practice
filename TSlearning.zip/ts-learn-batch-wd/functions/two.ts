//function parameter optional, default
//function n arguments
//fiunction overloading
//function object

//1//
function addition(x:number=0, y:number=0,z?:number){
    return x+y+(z||0);
}
let result = addition(10,20);
console.log(result);
console.log(addition(10,20,30));
console.log(addition());

//2//
function nArgsFn(...arg:number[]):number{
    return arg.reduce((prev,current)=>prev+current,0);
}
console.log(nArgsFn());
console.log(nArgsFn(10,20,30,40,50));
console.log(nArgsFn(1,2,3));

//3//
function search(price:number);
function search(brand:string);
function search(criteria:number|string){
    if(typeof criteria==='number'){
    console.log('Search By Price',criteria);
    }
    else{
        console.log('Search By Brand',criteria);
    }
}
search(10000);
search('Puma');

//3//
//use case of func overloading

type ApiOptions={
    url:string,body:string,headers?:[]
}
function doApiCall(url : string);//GET call
function doApiCall(fetchOptions : ApiOptions);//POST call
function doApiCall(fetchOptions : ApiOptions | string){
    //network call
    if(typeof fetchOptions==='string'){
        fetch(fetchOptions);
    }
    else{
        fetch(fetchOptions.url,{
            body:fetchOptions.body,
            headers:fetchOptions.headers
        });
    }
}

//call
doApiCall('https://official-joke-api.appspot.com/random_joke');
const options:ApiOptions={url:'https://official-joke-api.appspot.com/random_joke',body:"userid:'Divyansh'&pwd='a1222",headers:[]};
doApiCall(options);



