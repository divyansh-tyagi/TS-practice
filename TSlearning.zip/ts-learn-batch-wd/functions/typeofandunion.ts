type Employee={
    id:number, name:string,salary?:number
}

const emp1:Employee={id:1001,name:'Tim'}; 
const emp2:Employee={id:1002, name:'Tom', salary:80000};
const emp3:Employee={id:1003, name:'Tam'};

let emp4:Employee | null =null;
emp4={id:1004, name:'Tum'};

function show(arg:number|string|Employee){
    //type safe
    if(typeof arg==='number'){
        console.log(arg.toFixed(2))
    }
    else if(typeof arg==='string'){
        console.log(arg.toUpperCase());
    }
    else{
        console.log(arg.name);
    }

}

function show2(a:any){

}