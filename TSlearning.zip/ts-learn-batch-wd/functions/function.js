function add(x, y) {
    return x + y;
}
let z = add(100, 200);
console.log(z);
//implicit any
function adder(x, y) {
    console.log(x + y);
}
//adder()
//Async
function doAsyncTask(num) {
    const promise = new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve(Math.pow(num, 3));
        }, 4000);
    });
    return promise;
}
const promise = doAsyncTask(3);
promise.then(data => console.log('Cube', data)).catch(err => console.log(err));
//Anonymous function or Arrow Function
let prices = [1000, 2000, 4000, 50000];
prices.forEach((price) => console.log('Price is', price));
