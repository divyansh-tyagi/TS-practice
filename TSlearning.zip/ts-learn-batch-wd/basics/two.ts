//basic types
//Implicit way(type inference)
var x=100;
//x=true;
var y="Amit";

var z=true;

var r=undefined;
var r2=null;
var h=1000000000000000n;


//Explicit way
var a:number;
a=10;
a=100.20;
//a=10000n;

var b:string;
b="Divyansh Tyagi";

var c:boolean;
 c=true;
 var t:undefined;
 t=undefined;
 //t="hello";
 var t2:null;
 t2=null;
 //t2={id:10991};
 var t3:bigint=646548456384856858684385n;

 var t4=Symbol();