var _a;
//Wrappers- Rare to use
//reference types
var a = 10;
var t = [10, 20, 30]; //Implicit way
var t2 = [99, 1000, 200];
var t3 = [100, 20, 999, 100]; //generic style
var r = new String("Divyansh");
var r3 = new Number(1000);
var emp = { id: 1001, name: 'Ram' };
var student;
student = { id: 1001, name: 'ABC', course: 'TS' };
//student={id:1001, name:'ABC', course:'TS', city:'Delhi'};
console.log(student.id, student.name, (_a = student.city) === null || _a === void 0 ? void 0 : _a.toUpperCase());
