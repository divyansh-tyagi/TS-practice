function show(a, b) {
    return a + b;
}
console.log(show(10, 20));
//console.log(show("Ram","Kumar"));
