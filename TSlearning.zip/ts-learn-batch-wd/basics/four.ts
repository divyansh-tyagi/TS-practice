//Wrappers- Rare to use
//reference types
var a=10;
var t=[10,20,30];//Implicit way

var t2:number[]=[99,1000,200];
var t3:Array<number>=[100,20,999,100]; //generic style
var r:String=new String("Divyansh");
var r3:Number=new Number(1000);

var emp = {id:1001, name:'Ram'};

var student:{id:number, name:string, course:string, city?:string};
student={id:1001, name:'ABC', course:'TS'};
//student={id:1001, name:'ABC', course:'TS', city:'Delhi'};
console.log(student.id, student.name,student.city?.toUpperCase());

