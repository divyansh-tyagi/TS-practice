//any ,unknown, never
function getData() {
    throw new Error('Some thing went wrong');
    // while(true){
    // }
}
var j = getData();
console.log(j);
var e;
var f;
f = 10;
f = "hello";
f = true;
//console.log(f.toUpperCase());
var k;
k = 10;
k = "Hello";
//k=true;
if (typeof k === 'string') {
    console.log(k.toUpperCase);
}
else {
    console.log(k);
}
//known
var t = 100;
