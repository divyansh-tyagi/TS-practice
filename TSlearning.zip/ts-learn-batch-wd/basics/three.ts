//any ,unknown, never

function getData():never{
    throw new Error('Some thing went wrong');
   // while(true){

   // }
}
let j:never=getData();
console.log(j);


var e:any;

var f;
f=10;
f="hello";
f=true;
//console.log(f.toUpperCase());


var k:unknown;
k=10;
k="Hello";
//k=true;
if(typeof k==='string'){
console.log(k.toUpperCase);
}
else{
    console.log(k);
}



//known
var t:number=100;